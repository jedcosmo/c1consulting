<p>
	<?php
	printf(
		__( 'Please read the <a href="%s" target="_blank">settings guide</a> of the Page Builder documentation for help.', 'siteorigin-panels' ),
		'https://siteorigin.com/page-builder/documentation/settings/'
	);
	?>
</p>