<?php

return array(
	'clean' => array(
		'background_color' => '#FCFCFC',
		'borders' => '1px solid #D0D0D0',
	),
);
