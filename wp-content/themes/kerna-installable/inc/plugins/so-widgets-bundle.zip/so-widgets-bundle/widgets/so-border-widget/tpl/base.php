<?php if($instance['line']):?>
   <hr>
<?php endif;?>
