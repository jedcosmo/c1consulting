<div id="countdown" class="col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1 col-sm-12 col-xs-12">
    <div id="DateCountdown" data-date="<?php echo $instance['date'];?> 00:00:00" data-color:"#ffffff" ></div>
</div><!-- end countdown -->