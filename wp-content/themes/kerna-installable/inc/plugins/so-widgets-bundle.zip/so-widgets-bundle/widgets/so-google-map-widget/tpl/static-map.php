<img
	border="0"
	src="<?php echo sow_esc_url( $src_url ) ?>">
