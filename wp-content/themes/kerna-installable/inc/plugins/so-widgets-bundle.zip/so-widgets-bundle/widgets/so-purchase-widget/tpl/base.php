 
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="taglinemessage">
                        <div class="pull-left">
                        <h2><?php  echo $instance['title'];?></h2>
                        <p><?php  echo nl2br($instance['description']);?></p>
                         </div>
                         <a href="<?php echo $instance['buttonurl'];?>" class="pull-right btn btn-lg border-radius btn-transparent"><?php echo $instance['buttontext'];?></a>
                    </div><!-- end welcome -->
                </div><!-- end col -->
            </div><!-- end row -->
       